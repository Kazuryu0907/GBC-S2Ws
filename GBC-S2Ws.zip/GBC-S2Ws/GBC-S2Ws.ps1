./main.exe
Read-Host "Press any key to continue"